var prin , prin_running
var banana ,bananaImage, stone, stoneImage
var castle,castleImage
var Survival_Time=0 
var ground,groundImage
var  invisibleGround
var coin,coinImage,coinGroup
var brick, brickImage
var anna,annaImage
var anna2,anna2Image
var star,starImage
var prince,princeImage
var heart,heartImage
var heart2,heart2Image
var gameState="play"
var stline
var coins=0
var reset,resetImage
var sound1
var sound2
var sound3
var Star=0


function preload(){
  
  
  prin = loadAnimation( "cin1.jpg","cin2.jpg","cin3.jpg")
  prin1_running=loadAnimation("jump1.png")
 
  castleImage = loadImage("castle.jpg");
 groundImage=loadImage("ground2.png")
  coinImage=loadImage("coin.jpg")
  brickImage=loadImage("ground.png")
  annaImage=loadImage("anna.png")
  anna2Image=loadImage("anna2.jpg")
  starImage=loadImage("star.jpg")
  princeImage=loadImage("prince.jpg")
  heartImage=loadImage("heart.png")
resetImage=loadImage("restart.png")
  sound1=loadSound("jump00.mp3")
  sound2=loadSound("sound5.mp3")
  sound3=loadSound("die.mp3")
}



function setup() {
 
   castle=createSprite(400,windowHeight,0,0)
  castle.addImage(castleImage)
  castle.scale=5
  
 reset=createSprite(400,200,10,10)
  reset.addImage(resetImage)
  reset.visible=false
 
  
  stline=createSprite(282,48,windowWidth)
  stline.visible=false
  
prin1=createSprite(66,334,10,10)
  
  prin1.addAnimation("running",prin)
   prin1.addAnimation("jumping", prin1_running);
  prin1.scale=0.1

 prin1.scale=0.1
  
ground()
  
  
  invisibleGround =createSprite(66,370,500,10);
  invisibleGround.visible = false;
  
  coinGroup=new Group()
  annaGroup=new Group()
  anna2Group=new Group()
  princeGroup=new Group()
  starGroup=new Group()
  
  
    heart=createSprite(200,200,10,10)
  heart.addImage(heartImage)
  heart.scale=0.1
  heart.visible=false
  
     heart2=createSprite(250,250,10,10)
  heart2.addImage(heartImage)
  heart2.scale=0.1
    heart2.visible=false
  
    

   
  var Survival_Time=0
  var coins=0
  var Star=0
   
}


function draw() {
createCanvas(windowWidth,windowHeight);
  background("white")
  
  
if(mousePressedOver(reset)){
  reset.visible=false
}
 
 if(gameState==="play"){
  if(prin1.isTouching(ground)){
    prin1.changeAnimation("running",prin)
 }
   

  
  if(keyDown("space")&& prin1.y>=250) {
    prin1.velocityY = -20
   prin1.changeAnimation("jumping",prin1_running)	
    sound1.play()
  }
  
   prin1.velocityY = prin1.velocityY + 0.8
  
    castle.velocityX = -10

    if (castle.x < 0){
    castle.x = castle.width/2;
    }
  
  if (ground.x < 0){
    ground.x = ground.width/2;}
   
  
  if(heart.isTouching(stline)){
      heart.x=200
    heart.y=200
    heart2.x=250
      heart2.y=250
    heart.visible=false
    heart2.visible=false
  }
  
    prin1.collide(ground)
 
     prin1.collide(invisibleGround)
  
   
   
  coin()
  anna()
  anna2()
star()
 prince()
   
    if(prin1.isTouching(starGroup)){
    starGroup.destroyEach()
      sound2.play()
    Star=Star+1
  }
   
 
  
   if(prin1.isTouching(coinGroup)){
    coinGroup.destroyEach()
      sound2.play()
    coins=coins+1
  }
   
   if(prin1.isTouching(princeGroup)){
   heart.visible=true
   heart2.visible=true
   heart2.velocityY=-3
   heart.velocityY=-4
 }
  
 }
  

    
  
  
 
  
  
 
 if(prin1.isTouching(annaGroup)||prin1.isTouching(anna2Group)){
   gameState="end"
   sound3.play()
 }
  
   
  
  
  
  drawSprites()
  
 if(gameState==="end"){
   castle.velocityX=0
   ground.velocityX=0
   prin1.velocityX=0
   prin1.changeAnimation("jumping",prin1_running)
   textSize(40)
   fill("black")
   text("GAME OVER",400,400)
    Survival_Time=0
    princeGroup.destroyEach()
    annaGroup.destroyEach()
    anna2Group.destroyEach()
   reset.visible=true
   prin1.collide(ground)
  prin1.collide(invisibleGround)
   prin1.x= 600
   prin1.y= 200
   
 }
  
 
 
 
   text(" Survival_Time" +Survival_Time,282,48);
   Survival_Time=Math.round( Survival_Time+(frameCount/600))
  
   text("coins"+coins,150,48)
 text("Star"+Star,600,48)
 
}


function ground(){
   ground = createSprite(windowWidth,370,400,20);
ground.addImage(groundImage)
 ground.x = ground.width /2;
  ground.velocityX = -4;
  
}

function coin(){
  if(frameCount%100===0){
    var  coin=createSprite(330,340,10,10) 
 coin.y =Math.round(random(200,375))
   coin.addImage(coinImage)
      coin.scale=0.03
      coin.velocityX=-3
    coinGroup.add(coin)
  }
  }

function brick() {
  if(frameCount%200===0){
   brick=createSprite(500,200,10,10)
    brick.addImage(brickImage)
     brick.scale=0.5
}
  brickGroup.add(brick)
}

function anna(){
 if(frameCount%400===0){
  var anna=createSprite(windowWidth,340,10,10 )
   anna.addImage(annaImage)
   anna.scale=0.1
   anna.velocityX=-7
   annaGroup.add(anna)
 }
  }

 function anna2(){
   if(frameCount%600===0){
   var anna2=createSprite(windowWidth,340,10,10)
    anna2.addImage(anna2Image)
    anna2.scale=0.4
    anna2.velocityX=-12
     anna2Group.add(anna2)
  }
}

function star(){
  if(frameCount%10000===0){
    var star=createSprite(windowHeight,windowWidth,10,10)
    star.y=Math.round(random(200,375))
    star.addImage(starImage)
    star.scale=0.1
    star.velocityX=-7
    starGroup.add(star)
  }
}

function prince(){
  if(frameCount%500===0){
    var prince=createSprite(windowWidth,340,10,10)
    prince.addImage(princeImage)
    prince.scale=0.1
    prince.velocityX=-6
    princeGroup.add(prince)
  }
}


